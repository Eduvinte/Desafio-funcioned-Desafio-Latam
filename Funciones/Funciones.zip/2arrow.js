suma = (a, b) => {
    return a + b;
}

console.log(suma(5,5))
    