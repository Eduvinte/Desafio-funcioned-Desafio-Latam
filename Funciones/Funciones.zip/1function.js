let FuncionDeExpression = function example(a, b, c){
    return a+b+c;
}

console.log(FuncionDeExpression(5,5,5))